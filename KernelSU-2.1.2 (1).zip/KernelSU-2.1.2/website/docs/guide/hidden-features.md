# Hidden features

## .ksurc

By default, `/system/bin/sh` loads `/system/etc/mkshrc`.

You can make su load customized rc file by creating a `/data/adb/ksu/.ksurc` file.
